Vue.component("my-header",{
    template:`
    <div class="header-bottom-top">
		<div class="container">
			<div class="header-bottom">
				<div class="logo" style="margin-top:10px">
					<a href="index.html"><img src="../images/log.png"></a>
                </div>
                <div class="search">	
                    <input type="text">
                    <input type="submit" value="">
                </div>
				<div class="top-nav">
					<ul style="margin-bottom:0px">
						<li><a href="index.html">首页</a></li>
						<li><a href="news.html">新闻</a></li>
						<li><a href="teams.html">联赛</a></li>
					</ul>
                </div>
            </div>
		</div>
    </div>`
})
Vue.component("my-footer",{
	template:`
	<footer class="kode_footer_2">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="widget widget_text">
                        <div class="logo">
                            <a href="index.html"><img src="../images/ft_logo2.png" alt=""></a>
                        </div>
                        <ul class="kf_contact_meta">
                            <li>
                                <span class="icon-placeholder"></span>
                                <address>中国山东</address>
                            </li>
                            <li>
                                <span class="icon-mail"></span>
                                <p>guos971023@163.com</p>
                            </li>
                            <li>
                                <span class="icon-technology"></span>
                                <p>17660259775</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4" style="padding-top:20px;padding-bottom: 20px;">
                    <div>
                        <ul class="links_dec links_dec2">
                            <li><a href="index.html">首页</a></li>
                            <li><a href="news.html">新闻</a></li>
                            <li><a href="teams.html">五大联赛</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4" style="padding-left: 0px;padding-right: 0px;">
                    <div class="widget widget_instagram" >
                        <ul>
                            <li><a><img src="../images/insta1.jpg" alt=""></a></li>
                            <li><a><img src="../images/insta2.jpg" alt=""></a></li>
                            <li><a><img src="../images/insta3.jpg" alt=""></a></li>
                            <li><a><img src="../images/insta4.jpg" alt=""></a></li>
                            <li><a><img src="../images/insta5.jpg" alt=""></a></li>
                            <li><a><img src="../images/insta6.jpg" alt=""></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>`
})